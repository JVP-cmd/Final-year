package client;

import java.net.*; 
import java.io.*; 
import java.util.Scanner;
  
public class Client 
{ 
    // initialize socket and input output streams 
    public Socket socket            = null; 
    public DataInputStream  input   = null; 
    public DataOutputStream out     = null; 
  
    // constructor to put ip address and port 
    public Client(String address, int port) 
    { 
        // establish a connection 
        try
        { 
            socket = new Socket(address, port); 
            System.out.println("Connected"); 
  
            // takes input from terminal 
            input  = new DataInputStream(socket.getInputStream()); 
  
            // sends output to the socket 
            out    = new DataOutputStream(socket.getOutputStream()); 
        } 

        catch(Exception e) 
        { 
            System.out.println(e); 
        } 
  
      

    } 
  
    public static void main(String args[]) 
    { Login obj=new Login();
    obj.setVisible(true);
    
         }}