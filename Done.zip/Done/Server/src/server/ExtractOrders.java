/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Class used to extract data from the Order text file. Also temporarily stores order information
 *
 * @author joshv
 */
public class ExtractOrders {

    String filename = "";
    public ArrayList<String> pname = new ArrayList();
    public ArrayList<Integer> quant = new ArrayList();
    public ArrayList<Double> price = new ArrayList();

    /**
     * Method used during order manipulation to obtain the date from the order text file
     * @param file
     * @throws FileNotFoundException 
     */
    public ExtractOrders(String file) throws FileNotFoundException {
        filename = file;
        File order = new File("Orders\\" + filename);
        Scanner readorder = new Scanner(order);
        while (readorder.hasNextLine()) {
            String line = readorder.nextLine();
            System.out.println(line);

            String[] rec = line.split("%");
            if (rec.length < 2) {
                break;
            }
            pname.add(rec[0]);
            quant.add(Integer.parseInt(rec[1]));
            price.add(Double.parseDouble(rec[2]));
        }
    }
    
    /**
     * This method returns the total amount of the chosen order.
     * @return 
     */
    public double getTotal() {
        double total = 0;
        for (int i = 0; i < pname.size(); i++) {
            total += quant.get(i) * price.get(i);
        }
        total = (double) Math.round(total * 100) / 100;
        return total;
    }
}
