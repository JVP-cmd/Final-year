package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 */
public class Controller implements Runnable {

    protected Socket clientSocket = null;
    protected String serverText = null;

    public Controller(Socket clientSocket) {
        this.clientSocket = clientSocket;

    }

    public void run() {
        try {
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/SMGData", "a", "1");
            DataInputStream input = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream output = new DataOutputStream(clientSocket.getOutputStream());
            Model model=new Model();

            String in = input.readUTF();
           
            if (in.equals("Login")) {
                model.Login(input, output, con);
            }
            if (in.equals("Register")) {
                model.Register(input, output, con);
            }
            if (in.equals("ConsumerMenuStart")) {

                model.ConsumerMenuStartUp(input, output, con);
            }
            if (in.equals("ProductClicked")) {
                model.ProductClicked(input, output, con);
            }
            if (in.equals("SearchSMGMenu")) {
                model.SearchConsumerMenu(input, output, con);
            }
            if (in.equals("Order")) {
                model.Order(input, output, con,clientSocket);
            }
            if (in.equals("CartListClicked")) { //additonal code added here
                model.ProductClicked(input, output, con);
            }
            if (in.equals("SellerMenu")) {
                model.SellerMenu(input, output, con);
            }

            if (in.equals("editing product")) {

                model.Editproduct(input, output, con);
            }
            if (in.equals("add Product")) {
                model.checkProdName(input, output, con);
                boolean pExists = input.readBoolean();
                if (!pExists) {
                    model.AddProduct(input, output, con);
                }
            }
            if (in.equals("remove prod")) {
                model.RemoveProd(input, output, con);
            }
            if (in.equals("SellercOrder")) {
                model.OrderStartUp(input, output, con);
            }
            if (in.equals("AcceptedOrders")) {
                model.AcceptedOrders(input, output, con);
            }
            if (in.equals("Accept Order")) {
                model.AcceptOrder(input, output, con);
            }
            if (in.equals("Get Orders file")) {
                model.OrderFile(input, output);
            }
            if (in.equals("Decline Order")) {
                model.DeclineOrder(input, output, con);
            }
            if (in.equals("Completed")) {
                model.CompleteOrder(input, output, con);
            }
            if (in.equals("CompletedOrders")) {
                model.ShowCompletedOrders(input, output, con);
            }
            if (in.equals("Customer Orders")) {
                model.CustomerOrderStartUp(input, output, con);
            }
            con.close();
            input.close();
            output.close();
        } catch (IOException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }}}
    

   
