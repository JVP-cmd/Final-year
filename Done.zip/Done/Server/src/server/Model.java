/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * s
 *
 * @author joshv
 */
public class Model {

    /**
     * Method called by controller when controller receives "Customer Orders" request from the the client.
    Functionality for View:When a customer wants to view their orders (clicks on the order button in Consumer GUI)
    Inputs from client: customer username as username
    Inputs are used to generate a result set of orders linked only to the specific user.
    Each field in a  record of the result set is then stored into its respective variable and concatenated with each other separated by a "%" to form 1 String output variable
    Outputs:String output (out) is the parsed through the data output stream(parameters of method) to the client where it is received as an data input stream
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void CustomerOrderStartUp(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String username = input.readUTF();//customer username
        String query = "SELECT * FROM ORDERS WHERE USERNAME ='" + username + "'";
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        while (rs.next()) {//itterates through result set
            String orderno = rs.getString("ORDERNO");
            String shop = rs.getString("SHOP");
            String ec = rs.getString("EFTORCASH");
            if (ec.equals("e")) {//checks if payment method is eft or cash,converts to more user understandable string
                ec = "EFT";
            } else {
                ec = "Cash";
            }
            String date = rs.getString("DATE");
            String dorc = rs.getString("DORC");
            if (dorc.equals("d")) {//checks if delivery or collection, converts to more user understandable string
                dorc = "Delivery";
            } else {
                dorc = "Collection";
            }
            String status = rs.getString("STATUS");
            if (status.equals("0")) {//checks status, and converts to more user understandable string
                status = "Pending";
            } else if (status.equals("1")) {
                status = "Accepted";
            } else if (status.equals("2")) {
                status = "Completed";
            } else if (status.equals("3")) {
                status = "Declined";
            } else if (status.equals(dorc)) {
                status = "Reported";
            }
            String queryShopRg = "SELECT REGION, BANK, ACCOUNT,CONTACT FROM USERINFO WHERE SHOP ='" + shop + "'"; //second query used to locate the region and bank details of the Seller which is stored in USERINFO
            Statement ShopRg = con.createStatement();
            ResultSet ShopRgrs = ShopRg.executeQuery(queryShopRg);
            ShopRgrs.next();
            String region = ShopRgrs.getString("REGION");
            String bank = ShopRgrs.getString("BANK");
            String account = ShopRgrs.getString("ACCOUNT");
            String contact = ShopRgrs.getString("CONTACT");
            String out = orderno + "%" + date + "%" + shop + "%" + status + "%" + ec + "%" + dorc + "%" + bank + "%" + account + "%" + region + "%" + contact;

            System.out.println(out);
            output.writeUTF(out);
        }
        output.writeUTF("finish"); //parsed to client to indicate that the result set has sent its last record, stops client from waiting for more input.
    }

    /**
     * Called when the controller receives "CompletedOrders" from the client via Data input stream
    Functionality  for View:Used when a Seller wants to see their completed orders(SellerOrder GUI)
    Inputs from client: Name of the sellers shop
    Inputs are used to generates a result set of orders that are linked to the shop name and have been completed(product has been paid for)
    Each field in a  record of the result set is then stored into its respective variable and concatenated with each other separated by a "%" to form 1 String output variable
    Outputs:String output (out) is the parsed through the data output stream(parameters of method) to the client where it is received as an data input stream
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void ShowCompletedOrders(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String shop = input.readUTF();
        String query = "SELECT * FROM ORDERS WHERE SHOP= '" + shop + "' AND STATUS = 2";
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        while (rs.next()) {
            String orderno = rs.getString("ORDERNO");
            String address = rs.getString("ADDRESS");
            String region = rs.getString("REGION");
            String province = rs.getString("PROVINCE");
            String ec = rs.getString("EFTORCASH");
            String date = rs.getString("DATE");
            String dorc = rs.getString("DORC");
            String code = rs.getString("POSTALCODE");
            String consumer = rs.getString("USERNAME");

            query = "SELECT CONTACT FROM USERINFO WHERE USERNAME='" + consumer + "'";
            Statement statContact = con.createStatement();
            ResultSet rsContact = statContact.executeQuery(query);
            rsContact.next();
            String contact = rsContact.getString("CONTACT");
            if (ec.equals("e")) {
                ec = "EFT";
            } else {
                ec = "Cash";
            }

            if (dorc.equals("d")) {
                dorc = "Delivery";
            } else {
                dorc = "Collection";
            }
            String out = orderno + "%" + address + "%" + region + "%" + province + "%" + ec + "%" + dorc + "%" + date + "%" + contact + "%" + code;
            output.writeUTF(out);
        }
        output.writeUTF("finish"); //parsed to client to indicate that the result set has sent its last record, stops client from waiting for more input.
    }

    /**
     * Called when the controller receives "Completed" from the client via Data input stream
    Functionality for view:When a seller wishes to complete order after they have received the cash/proof of payment(SellerOrders GUI)
    Inputs from client:Order number(primary key),name of shop 
    Order number is used to locate the order textfile which contains the name of the products,quantity requested and price
    name of shop is used in conjuction with contents of the textfile to create a set of queries that locate specific records in the products table (records of the desired products)
    The fields of the result set are then used to check if the order can be completed or if there is not enough stock to complete the order
    if the order can be completed, the quantity of each product in the order textfile is subtracted from the stock and displayed stock fields of the respective product records.
    if it could complete then no fields are updated in product record and the last output to the client will be a list of the products that had insufficient stock
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void CompleteOrder(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String orderno = input.readUTF();//inputs
        String shop = input.readUTF();//inputs
        ExtractOrders eo = new ExtractOrders(orderno + ".txt");//object used to extract the date from order text file
        boolean noStock = false;//checks if any product is insufficient to comeplete the order
        String RunOutOfStock = "Ran out of the following stocks:\n"; //sent to client after the checks have been done for each prodcut, will remain the same if all products pass
        int[] displayedstock = new int[eo.pname.size()];
        int[] stock = new int[eo.pname.size()];

        for (int i = 0; i < eo.pname.size(); i++) {//obatining the specific product records using shop name and product name (product name retrieved from orders text file)
            Statement stat = con.createStatement();
            String query = "SELECT DISPLAYEDSTOCK,STOCK FROM PRODUCTS WHERE SHOP='" + shop + "' AND PNAME ='" + eo.pname.get(i) + "'";
            ResultSet rs = stat.executeQuery(query);
            if(rs.next()){
            displayedstock[i] = Integer.parseInt(rs.getString("DISPLAYEDSTOCK"));
            stock[i] = Integer.parseInt(rs.getString("STOCK"));
            if (displayedstock[i] < eo.quant.get(i)) {
                RunOutOfStock += eo.pname.get(i) + "\n";
                noStock = true;
            }
        }
            else{RunOutOfStock+="Product no longer exists "+eo.pname.get(i)+"\n";
            noStock=true;}}
        output.writeUTF(RunOutOfStock);
        if (!noStock) { // if all products passed the check, the respective product records are updated
            Statement comp = con.createStatement();

            String compQuery = "UPDATE ORDERS SET STATUS = 2 WHERE ORDERNO ='" + orderno + "'";
            comp.executeUpdate(compQuery);
            for (int i = 0; i < eo.pname.size(); i++) {
                Statement product = con.createStatement();
                System.out.println(stock[i]-eo.quant.get(i));
                String prodQuery = "UPDATE PRODUCTS SET DISPLAYEDSTOCK = " + (displayedstock[i] - eo.quant.get(i)) + ",STOCK = " + (stock[i] - eo.quant.get(i)) + " WHERE PNAME='" + eo.pname.get(i) + "' AND SHOP ='" + shop + "'";
                product.executeUpdate(prodQuery);
            }
        }
    }
 
    /**
     * Called when the controller receives "Decline Order" from the client via Data input stream
    Functionality for view: Seller clicks on the decline order button, to decline the order(SellerORders GUI)
    Inputs from client: order number
    Update query is created to change the status of the order from 0 to 3(pending to declined); 
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
  
    public void DeclineOrder(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String orderno = input.readUTF();
        Statement stat = con.createStatement();
        String query = "UPDATE ORDERS SET STATUS = 3 WHERE ORDERNO ='" + orderno + "'";
        stat.executeUpdate(query);
    }

    /**
     * Called when the controller receives "Get Orders file" from the client via Data input stream
    Functionality for view:used in the SellerOrder GUI when seller clicks on an order in the OrderLst, populates Arraylists in  SellerOrder class
    Inputs from client:Order number
    retrieves the contents of an Order textFile(product name, desired quantity and price) and sends it to the client
     * @param input
     * @param output
     * @throws IOException 
     */
    public void OrderFile(DataInputStream input, DataOutputStream output) throws IOException {
        String orderno = input.readUTF();
        ExtractOrders eo = new ExtractOrders(orderno + ".txt");
        output.writeUTF("R" + eo.getTotal());
        for (int i = 0; i < eo.pname.size(); i++) { //combining product name,desiered quantity and price into one string that can be split by the client using "%"
            String out = eo.pname.get(i) + "%" + eo.quant.get(i) + "%" + eo.price.get(i);
            output.writeUTF(out);
        }
        output.writeUTF("finish");//parsed to client to indicate that the result set has sent its last record, stops client from waiting for more input.
    }

    /**
     * Called when the controller receives "Accept Order" from the client via Data input stream
    Functionality for view: Seller clicks on the accept order button, to accept the order(SellerORders GUI)
    Inputs from client: order number
    Update query is created to change the status of the order from 0 to 1(pending to accepted); 
     * 
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void AcceptOrder(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String orderno = input.readUTF();
        String query = "UPDATE ORDERS SET STATUS = 1 WHERE ORDERNO ='" + orderno + "'";
        Statement stat = con.createStatement();
        stat.executeUpdate(query);
    }
    

    /** Called when the controller receives "AcceptedOrders" from the client via Data input stream 
    Functionality for view: Seller wishes to view all accepted orders
    Inputs from client:name of the shop
    Inputs are used to generate a result set that only contains records of the accepted orders that correspond to the Shop
    Each field in a  record of the result set is then stored into its respective variable and concatenated with each other separated by a "%" to form 1 String output variable
    Outputs:String output (out) is the parsed through the data output stream(parameters of method) to the client where it is received as an data input stream
     * 
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void AcceptedOrders(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {

        String shop = input.readUTF();
        String query = "SELECT * FROM ORDERS WHERE SHOP= '" + shop + "' AND STATUS = 1";
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        while (rs.next()) {
            String orderno = rs.getString("ORDERNO");
            String address = rs.getString("ADDRESS");
            String region = rs.getString("REGION");
            String province = rs.getString("PROVINCE");
            String ec = rs.getString("EFTORCASH");
            String date = rs.getString("DATE");
            String dorc = rs.getString("DORC");
            String code = rs.getString("POSTALCODE");
            String consumer = rs.getString("USERNAME");

            query = "SELECT CONTACT FROM USERINFO WHERE USERNAME='" + consumer + "'";
            Statement statContact = con.createStatement();
            ResultSet rsContact = statContact.executeQuery(query);
            rsContact.next();
            String contact = rsContact.getString("CONTACT");
            if (ec.equals("e")) {
                ec = "EFT";
            } else {
                ec = "Cash";
            }

            if (dorc.equals("d")) {
                dorc = "Delivery";
            } else {
                dorc = "Collection";
            }
            String out = orderno + "%" + address + "%" + region + "%" + province + "%" + ec + "%" + dorc + "%" + date + "%" + contact + "%" + code;
            output.writeUTF(out);
        }
        output.writeUTF("finish");
    }
 
    /**
     * Called when the controller receives "SellercOrder" from the client via Data input stream 
       Functionality for view:When the SellerOrders is set visible, list of new orders for products from their shop are displayed to the seller
       Inputs from client: Seller username
       Their username is used to obtain the seller shop name which is then used to create another query that populates a Result Set with orders that are pending and related to the specific shop
     * Each field in a  record of the result set is then stored into its respective variable and concatenated with each other separated by a "%" to form 1 String output variable
       Outputs:String output (out) is the parsed through the data output stream(parameters of method) to the client where it is received as an data input stream
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void OrderStartUp(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String username = input.readUTF();
        String query = "SELECT SHOP FROM USERINFO WHERE USERNAME='" + username + "'";
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        rs.next();
        String shop = rs.getString("SHOP");
        output.writeUTF(shop);
        String querySellerOrders = "SELECT * FROM ORDERS WHERE SHOP= '" + shop + "' AND STATUS = " + 0;
        rs = stat.executeQuery(querySellerOrders);
        while (rs.next()) {
            String orderno = rs.getString("ORDERNO");
            String address = rs.getString("ADDRESS");
            String region = rs.getString("REGION");
            String province = rs.getString("PROVINCE");
            String ec = rs.getString("EFTORCASH");
            String date = rs.getString("DATE");
            String dorc = rs.getString("DORC");
            String code = rs.getString("POSTALCODE");
            String consumer = rs.getString("USERNAME");

            querySellerOrders = "SELECT CONTACT FROM USERINFO WHERE USERNAME='" + consumer + "'";
            Statement statContact = con.createStatement();
            ResultSet rsContact = statContact.executeQuery(querySellerOrders);
            rsContact.next();
            String contact = rsContact.getString("CONTACT");
            if (ec.equals("e")) {
                ec = "EFT";
            } else {
                ec = "Cash";
            }

            if (dorc.equals("d")) {
                dorc = "Delivery";
            } else {
                dorc = "Collection";
            }
            String out = orderno + "%" + address + "%" + region + "%" + province + "%" + ec + "%" + dorc + "%" + date + "%" + contact + "%" + code;
            output.writeUTF(out);
        }
        output.writeUTF("finish");
    }
    /**
     * Called when the controller receives "remove prod" from the client via Data input stream  from the client
     * Functionality for the view:Seller would like to remove a product from the database and their shop (Seller GUI)
     * Input from client: shop name and product name.
     * The product name and shop name are used to generate a result set of 1 specific product record that is to be deleted.
     * The IMAGE field of this record is retrieved and used to locate the image file linked to the specific product and it is then deleted
     * An update query is executed after and the product record is deleted(using shop name and product name)
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void RemoveProd(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String shop = input.readUTF();
        String name = input.readUTF();
        Statement stat = con.createStatement();
        String query2 = "SELECT * FROM PRODUCTS WHERE PNAME ='" + name + "' AND SHOP ='" + shop + "'";

        ResultSet res = stat.executeQuery(query2);

        res.next();

        String fileloc = res.getString("IMAGE");
        System.out.println(fileloc);
        File delete = new File("IMAGES\\" + fileloc);
        delete.delete();

        String query = "DELETE FROM PRODUCTS WHERE SHOP ='" + shop + "' AND PNAME ='" + name + "'";
        stat.executeUpdate(query);

    }
    /**
     *  Called when the controller receives "add Product" from the client via Data input stream  from the client
     * Functionality for the view:Seller clicks on Add product button in the Seller GUI and product is added to database
     * Inputs from client:name of shop and product name,price of product,stock of product,displayed stock of product(stock consumer sees)
     * Inputs are used to generate an insert query to insert the product into the database
     * File with the name of the shop and product name separated by a '%' is created and the product image is written to it using the input stream
     * @param input
     * @param output
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void AddProduct(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String shop = input.readUTF();
        String pname = input.readUTF();

        String price = input.readUTF();

        String stock = input.readUTF();
        String displayed = input.readUTF();
        LocalDate dl = LocalDate.now();
        String query = "INSERT INTO PRODUCTS(PNAME,SHOP,PRICE,STOCK,IMAGE,DISPLAYEDSTOCK,DATE) VALUES('" + pname + "','" + shop + "'," + price + "," + stock + ",'" + shop + "%" + pname + ".jpg'," + displayed + ",'" + dl + "')";
        Statement stat = con.createStatement();
        stat.executeUpdate(query);
        File image = new File("Images\\" + shop + "%" + pname + ".jpg");
        image.createNewFile();
        FileOutputStream fout = new FileOutputStream(image);
        int b;
        while ((b = input.read()) > -1) {
            fout.write(b);
        }

        fout.flush();
        fout.close();
    }
/**Called when the controller receives "add Product" from the client via Data input stream  from the client
 * Functionality for the view: Checks that the product name being added to the database does not already exist for the specific shop (shop and prod name form composite key for products table)
 * Inputs from client:Product name and shop name.
 * Inputs are used to create a query that generates a result set with either a record of 1 or 0, if 1 then product exists, if 0 product does not exist.
 * Writes a boolean object through Data output stream to client, boolean indicates if the product exists or not
 * @param input
 * @param output
 * @param con
 * @throws IOException
 * @throws SQLException 
 */
    public void checkProdName(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
        String pname = input.readUTF();
        String shop = input.readUTF();
        Statement stat = con.createStatement();

        String query = "SELECT * FROM PRODUCTS WHERE PNAME ='" + pname + "' AND SHOP ='" + shop + "'";
        ResultSet rs = stat.executeQuery(query);
        if (rs.next()) {
            output.writeBoolean(true);//exists
        } else {
            output.writeBoolean(false);//doesnt exist
        }
    }
/**Called when the controller receives "editing product" from the client via Data input stream  from the client
 * Functionality for view:Seller wishes to change details pertaining to a product(excluding product name)
 * Inputs from client:Shop and product name, price, stock, displayed stock and a boolean determining if a new product image is being uploaded for the specific product
 * The inputs are used to create  and update query which is then used to update the selected record.
 * if a new image is being uploaded to the server determined by updateimage boolean, the old image file is deleted and a new one with the same name is created for the new image to be uploaded to.
 * 
 * @param input
 * @param output
 * @param con
 * @throws IOException
 * @throws SQLException 
 */
    public void Editproduct(DataInputStream input, DataOutputStream output, Connection con) throws IOException, SQLException {
       String shop = input.readUTF();
        String pname = input.readUTF();
        String oldpname = input.readUTF();
        String price = input.readUTF();

        String stock = input.readUTF();
        String displayed = input.readUTF();
        boolean updateimage=input.readBoolean();
        String query = "UPDATE PRODUCTS SET PNAME ='" + pname + "',PRICE =" + price + ",STOCK=" + stock + ", DISPLAYEDSTOCK =" + displayed + ",IMAGE ='"+shop+"%"+pname+".jpg' WHERE SHOP ='" + shop + "' AND PNAME='" + oldpname + "'";
        Statement stat = con.createStatement();
        stat.executeUpdate(query);
        if(updateimage){
        
        File oldimage=new File("Images\\"+shop+"%"+oldpname+".jpg");
        oldimage.delete();
        File image = new File("Images\\" + shop + "%" + pname + ".jpg");
        image.createNewFile();
        FileOutputStream fout = new FileOutputStream(image);
        int b;
        while ((b = input.read()) > -1) {
            fout.write(b);
        }

        fout.flush();
        fout.close();}

    }
/**Called when the controller receives "Login" from the client via Data input stream  from the client
 * Functionality for view:Checks if username and password correspond to a record and depending on the output allows the user to proceed to the next GUI or not
 * Inputs from client:Username and Password
 * Inputs are used to create a query that will generate a result set with a single record or 0 records depending if the username and password are correct or not
 * Outputs a boolean log (if true login was success or false if failed) as well as a string that determines what type of user it is 
 * @param input
 * @param output
 * @param con 
 */
    public void Login(DataInputStream input, DataOutputStream output, Connection con) {
        try {
            try {

                Statement stat = con.createStatement();
                ResultSet rs = null;
                String query = "";

                String username = input.readUTF();
                String password = input.readUTF();
                boolean log = false; 
                query = "Select * from USERINFO Where USERNAME='" + username + "' and PASSWORD='" + password + "'";
                rs = stat.executeQuery(query);
                String cOs = " ";
                if (rs.next()) {
                    log = true;
                    cOs = rs.getString("COS");

                }
                output.writeUTF(cOs);
                output.writeBoolean(log);

            } catch (SQLException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException e) {
            //report exception somewhere.
            e.printStackTrace();
        }
    }
/**Called when the controller receives "Order" from the client via Data input stream  from the client
 * Functionality for view:Creates an order when Customer clicks 'Send Order' button in the Checkout GUI
 * Inputs from client: Customers username, name of the shop being purchased from , delivery or collection (dorc), address too be delivered too, region to be delivered too, postal code,province and payment method (EFT or Cash),Cart textfile(textfile containing a list of products that the user is purchasing)
 * Inputs are used to create an insert query alongside an order number that is generated by adding a random number between 1 and 1000 to the username.
 * @param in
 * @param out
 * @param con
 * @param clientSocket
 * @throws IOException
 * @throws SQLException 
 */
    public void Order(DataInputStream in, DataOutputStream out, Connection con, Socket clientSocket) throws IOException, SQLException {//additional code added here
        Statement stat = con.createStatement();
        ResultSet rs;
        String username = in.readUTF();
        String shop = in.readUTF();
        String dorc = in.readUTF();//Delivery or Collection
        String address = in.readUTF();
        String region = in.readUTF();
        String code = in.readUTF();
        String province = in.readUTF();
        String paymeth = in.readUTF();
        boolean exists = true;
        String orderno = "";
        while (exists) { //generates and checks order number against existing order numbers
            double num = (Math.random() * 1000) - 1;
            long num1 = Math.round(num);
            orderno = num1 + username;
            String query = "SELECT * FROM ORDERS WHERE ORDERNO = '" + orderno + "'";
            rs = stat.executeQuery(query);
            if (!rs.next()) {
                exists = false;
            }
        }
        LocalDate dl = LocalDate.now();

        int status = 0;


        String query2 = "INSERT INTO ORDERS(USERNAME,SHOP,ADDRESS,REGION,POSTALCODE,PROVINCE,EFTORCASH,DORC,STATUS,ORDERNO,DATE) VALUES('" + username + "','" + shop + "','" + address + "','" + region + "','" + code + "','" + province + "','" + paymeth + "','" + dorc + "'," + status + ",'" + orderno + "','" + dl + "')";
        stat.executeUpdate(query2);
        byte[] b = new byte[2002];//creates a copy of the cart textfile on the server side with a unique name(order number)
        InputStream is = clientSocket.getInputStream();
        FileOutputStream fo = new FileOutputStream("Orders\\" + orderno + ".txt");
        is.read(b, 0, b.length);
        fo.write(b, 0, b.length);
    }
    /**Called when the controller receives "ConsumerMenuStart" from the client via Data input stream  from the client
     * Functionality for the view:Displays all available product(products with a displayed stock value greater than 0)
     * Inputs from client;No inputs
     * Generates a result record of the product table, the fields of the result record are saved into the respective variables, displayed stock is then checked to see if it is not 0 if it is not then the record is outputed to the client
     * @param in
     * @param out
     * @param DBcon
     * @throws SQLException
     * @throws IOException 
     */
    public void ConsumerMenuStartUp(DataInputStream in, DataOutputStream out, Connection DBcon) throws SQLException, IOException {

        
        String query = "SELECT PNAME,p.SHOP,PRICE,DISPLAYEDSTOCK,DATE,REGION FROM PRODUCTS p, USERINFO u WHERE p.SHOP = u.SHOP";
        Statement stat = DBcon.createStatement();
        ResultSet res = stat.executeQuery(query);

        while (res.next()) {
            String pname = res.getString("PNAME");
            String shop = res.getString("SHOP");
            String price = res.getString("PRICE");
            String ds = res.getString("DISPLAYEDSTOCK");
            String reg = res.getString("REGION");
            String date = res.getString("DATE");
            int dsnum = Integer.parseInt(ds);
            if (dsnum > 0) {
                String obj = String.format("%-35s%-35s%-15s%-10s%-35s%-20s", pname, shop, price, ds, reg, date);

                out.writeUTF(obj);
            }
        }
        out.writeUTF("finish");
    }
    /**Called when the controller receives "ProductClicked" from the client via Data input stream  from the client
     * Functionality for view:When a Customer clicks on the Consumer Product List , the image of the product is displayed
     * Inputs from client:Product name and Shop name
     * Inputs are used to create a query to generate a result set from the products table that contains 1 record for the specific product, the location of image file is then obtained
     * Image file is then parse through the output stream to the client
     * @param in
     * @param out
     * @param DBcon
     * @throws IOException
     * @throws SQLException 
     */
    public void ProductClicked(DataInputStream in, DataOutputStream out, Connection DBcon) throws IOException, SQLException {
        String pname = in.readUTF();
        String shopName = in.readUTF();

        String query = "SELECT IMAGE FROM PRODUCTS WHERE PNAME = '" + pname + "' AND SHOP = '" + shopName + "'";
        Statement stat = DBcon.createStatement();
        ResultSet res = stat.executeQuery(query);
        res.next();

        String fileloc = res.getString("IMAGE");
        //new code starts here
        int i;

        FileInputStream fis = new FileInputStream(new File("Images\\" + fileloc));

        while ((i = fis.read()) > -1) {//reading in image file and writing to the client via outputstream
            out.write(i);
        }

        fis.close();

    }
    /**Called when the controller receives "SellerMenu"" from the client via Data input stream  from the client
     * Functionality for the view:Displays a list of the Sellers products as well as there stock,price and Displayed stock
     * Inputs from client:Sellers username
     * Input is used to create a query that generates a result record of 1 , this record is used to obtain the name of the shop belonging to the user. the name of the shop is used to create a  2nd
     * query that generates a result record of all the products belonging to that shop. These records are then are parsed through to the client via the data output stream in a formatted string
     * @param in
     * @param out
     * @param con
     * @throws IOException
     * @throws SQLException 
     */
    public void SellerMenu(DataInputStream in, DataOutputStream out, Connection con) throws IOException, SQLException {
        String username = in.readUTF();
        String query = "SELECT SHOP FROM USERINFO WHERE USERNAME='" + username + "'";
        Statement stat = con.createStatement();
        ResultSet rs = stat.executeQuery(query);
        rs.next();
        String shop = rs.getString("SHOP");
        out.writeUTF(shop);
        query = "SELECT PNAME,PRICE,STOCK,DISPLAYEDSTOCK FROM PRODUCTS WHERE SHOP = '" + shop + "'";
        rs = stat.executeQuery(query);
        while (rs.next()) {
            String pname = rs.getString("PNAME");
            String price = rs.getString("PRICE");
            String stock = rs.getString("STOCK");
            String ds = rs.getString("DISPLAYEDSTOCK");
            String output = pname + "%" + price + "%" + stock + "%" + ds;
            out.writeUTF(output);
        }
        out.writeUTF("finish");
    }
    /**Called when the controller receives "SearchSMGMenu"" from the client via Data input stream  from the client
     * Functionality for the view:Allows the customer to search for products based product name or/and shop name or/and region or/and date
     * Inputs from client:product name,shop name,Region of Shop, date product was added to the database
     * inputs are used to generate a query that generates a result record, the result record is then converted to a string and parse to the client via the data output stream in formated string
     * @param in
     * @param out
     * @param DBcon
     * @throws IOException
     * @throws SQLException 
     */
    public void SearchConsumerMenu(DataInputStream in, DataOutputStream out, Connection DBcon) throws IOException, SQLException {
        String product = in.readUTF();
        String shop = in.readUTF();
        String region = in.readUTF();
        String date = in.readUTF();
        String query = "";

        String productSQL = "";
        String shopSQL = "";
        String regionSQL = "";
        String dateSQL = "";

        if (!product.equals("")) {
            productSQL = " AND PNAME ='" + product + "'";
        }
        if (!shop.equals("")) {
            shopSQL = " AND p.SHOP ='" + shop + "'";
        }
        if (!region.equals("")) {
            regionSQL = " AND REGION ='" + region + "'";;
        }
        if (!date.equals("")) {
            dateSQL = " AND DATE = '" + date + "'";
        }

        query = "SELECT PNAME,p.SHOP,PRICE,DISPLAYEDSTOCK,REGION,DATE FROM PRODUCTS p, USERINFO u WHERE p.SHOP = u.SHOP" + productSQL + shopSQL + regionSQL + dateSQL;
        Statement stat = DBcon.createStatement();
        ResultSet res = stat.executeQuery(query);

        while (res.next()) {
            String pname = res.getString("PNAME");
            String Recshop = res.getString("SHOP");
            String price = res.getString("PRICE");
            String ds = res.getString("DISPLAYEDSTOCK");
            String reg = res.getString("REGION");
            String dateRs = res.getString("DATE");
            String obj = String.format("%-35s%-35s%-35s%-35s%-35s%-35s", pname, Recshop, price, ds, reg, dateRs);
            System.out.println(obj);
            out.writeUTF(obj);
        }
        out.writeUTF("finish");
    }
    /**
     * Called when the Controller receives "Register from the client via DataInputStream.
     * Functionality for the view:Allows a user to register for a consumer or seller account.
     * Inputs from client: name, surname, contact, region, CoS, storeName, bank, account, password
     * inputs are used to generate an insert statement that will register a new user with the input details into the UserInfo table in the database.
     * @param input
     * @param output
     * @param con 
     */
    public void Register(DataInputStream input, DataOutputStream output, Connection con) {
        try {
            try {

                String query = "";
                String username = "";
                String password = input.readUTF();
                String name = input.readUTF();
                String surname = input.readUTF();
                String contact = input.readUTF();
                String region = input.readUTF();
                String cos = input.readUTF();
                String Shop = input.readUTF();
                //String accountHolder = input.readUTF();
                String accountNumber = input.readUTF();
                String bankName = input.readUTF();

                query = "INSERT INTO USERINFO(USERNAME, PASSWORD, NAME, SURNAME, CONTACT, REGION, COS, SHOP, BANK, ACCOUNT)" + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                //rs = stat.executeQuery(query);
                PreparedStatement prepStat = con.prepareStatement(query);
                username = generateUsername(name, surname, con);
                output.writeUTF(username);
                prepStat.setString(1, username);
                prepStat.setString(2, password);
                prepStat.setString(3, name);
                prepStat.setString(4, surname);
                prepStat.setString(5, contact);
                prepStat.setString(6, region);
                prepStat.setString(7, cos);
                prepStat.setString(8, Shop);
                prepStat.setString(9, bankName);
                prepStat.setString(10, accountNumber);

                prepStat.execute();

            } catch (SQLException ex) {
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException e) {
            //report exception somewhere.
            e.printStackTrace();
        }
    }

    /**
     * A method used during Register to generate a unique username for a user using their name, surname and a randomly generated set of 3 numbers. The generated username is checked against the existing users to ensure the username is not taken, if taken the method will recursively repeat the process until a unique username is obtained.
     * Inputs from the Register method are name, surname of the user.
     * @param name
     * @param surname
     * @param con
     * @return
     * @throws SQLException 
     */
    private String generateUsername(String name, String surname, Connection con) throws SQLException {
        Statement stat = con.createStatement();
        ResultSet rs = null;
        String username = name.substring(0, 3) + "" + surname.substring(0, 3);
        username = username.toUpperCase();
        //assign a random number
        Random random = new Random();
        int num = random.nextInt(999);
        String code = Integer.toString(num);
        while (code.length() != 3) {
            code = "0" + code;
        }
        username = username + code;
        String existQuery = "SELECT * FROM USERINFO WHERE USERNAME = '" + username + "'";
        rs = stat.executeQuery(existQuery);
        if (rs.next()) {
            generateUsername(name, surname, con);
        }
        return username;
    }
}
